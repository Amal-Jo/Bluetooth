package com.example.bluetoothapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Set;

public class MainActivity extends AppCompatActivity {
    BluetoothAdapter BA;
    Button off,find,paired;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        off=(Button)findViewById(R.id.buttonOff);
        find=(Button)findViewById(R.id.findDevices);
        paired=(Button)findViewById(R.id.pairedDevices);

        off.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BluetoothOff();
            }
        });
        find.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FindDevices();
            }
        });
        paired.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PairedDevices();

            }
        });


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.


        int id= item.getItemId();
        //noinspection SimplifiableIfStatement

        if (id==R.id.action_settings){
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void BluetoothOff() {

        BA.disable();
        Log.i("off","working");
        if (BA.isEnabled()){
            Toast.makeText(getApplicationContext(),"Bluetooth could not be disabled",Toast.LENGTH_LONG).show();

        }
        else {
            Toast.makeText(getApplicationContext(),"Bluetooth turned off",Toast.LENGTH_LONG).show();
        }
    }

    public void FindDevices() {
        Intent intent=new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
        Log.i("finding","working");
        startActivity(intent);
    }

    public void PairedDevices() {
        Set<BluetoothDevice> pairedDevices =BA.getBondedDevices();

        ListView pairedDevicesListview=(ListView)findViewById(R.id.listView);

        ArrayList PairedDevicesArrayList=new ArrayList();
        Log.i("pair","working");

        for (BluetoothDevice bluetoothDevice:pairedDevices){

            PairedDevicesArrayList.add(bluetoothDevice.getName());

        }
        ArrayAdapter arrayAdapter=new ArrayAdapter(this,android.R.layout.simple_list_item_1,PairedDevicesArrayList);
         pairedDevicesListview.setAdapter(arrayAdapter);
        Log.i("pair","list added");

    }

}